# AFRIVISION — Guide du site

Ce dossier contient le site AFRIVISION complet. C'est un site **statique** : il n'y a ni base de données ni serveur à gérer, donc il est rapide, sûr et gratuit à héberger.

## 1. Contenu du dossier

| Élément | Rôle |
|---|---|
| `index.html` | Page d'accueil (bannière « À la une », contenus récents, rangées par rubrique) |
| `rubrique.html` | Page d'une rubrique, avec un filtre par thème |
| `video.html` | Page d'une vidéo, avec le lecteur intégré |
| `formation.html` | Page d'une formation et de ses modules |
| `article.html` | Page d'un article ou d'une fiche, avec ses sources |
| `recherche.html` | Recherche dans tout le site |
| `liste.html` | « Ma liste » : favoris enregistrés sur l'appareil du visiteur |
| `a-propos.html`, `contact.html`, `merci.html`, `mentions-legales.html`, `404.html` | Pages d'information |
| `content/` | **Tous les contenus** (vidéos, formations, articles, rubriques, réglages) au format JSON |
| `images/uploads/` | Les images que vous ajoutez depuis l'espace de gestion |
| `admin/` | **L'espace de gestion** (Sveltia CMS, gratuit) |
| `assets/` | Design (CSS), fonctionnement (JavaScript), polices, logo |
| `netlify.toml` | Réglages Netlify (sécurité, cache, préparation automatique) |
| `_build/prepare.js` | Lancé par Netlify à chaque publication : met l'adresse réelle du site dans l'aperçu de partage et crée le plan du site `sitemap.xml` |

## 2. Gérer les contenus sans toucher au code

L'espace de gestion se trouve à l'adresse `https://votre-site.netlify.app/admin/`. Il fonctionne sur iPhone.

Il vous permet d'**ajouter, modifier et supprimer** des vidéos, des formations, des articles et des images, et de modifier les textes du site. Chaque enregistrement met le site à jour automatiquement en une à deux minutes.

### Première connexion (une seule fois)

1. Le site doit être déposé sur **GitHub** (dépôt `afrivision`) et relié à **Netlify**.
2. Dans `admin/config.yml`, remplacez `VOTRE-NOM-GITHUB` par votre nom d'utilisateur GitHub.
3. Sur GitHub : **Settings › Developer settings › Personal access tokens › Fine-grained tokens › Generate new token**.
   - Accès : uniquement le dépôt `afrivision`.
   - Permission : **Contents › Read and write**.
4. Ouvrez `/admin/`, choisissez la connexion par jeton (« token ») et collez-le.
5. Ne partagez jamais ce jeton. S'il est perdu ou volé, supprimez-le sur GitHub et créez-en un autre.

### Ajouter une vidéo

1. **Vidéos › Toutes les vidéos › Ajouter**.
2. Remplissez le titre, l'identifiant (ex. `cours-anglais-debutant`), la rubrique, le thème et la description.
3. Collez le **lien** YouTube, Vimeo, Internet Archive, video.blender.org ou d'un fichier .mp4.
4. Indiquez la **source** et les **droits** (ex. « Licence Creative Commons BY » ou « Accord écrit du créateur »).
5. Enregistrez.

### Créer une formation

Ajoutez d'abord les vidéos et les articles. Ensuite, créez la formation et, pour chaque module, indiquez le **type** (vidéo ou article) et l'**identifiant** du contenu.

## 3. Contenus inclus (vérifiés le 19 novembre 2026)

| Rubrique | Contenus | Sources et droits |
|---|---|---|
| Media | 4 vidéos, 1 article | Films ouverts du Blender Studio (licence CC BY), vidéo et image de l'Agence spatiale européenne (CC BY-SA 3.0 IGO) |
| Academy | 1 vidéo, 2 articles | Vidéo IRCC (intégration autorisée), fiches AFRIVISION, liens vers Khan Academy, FUN MOOC, Elements of AI, CIFAR |
| Développement personnel | 4 articles, 1 formation | Fiches originales AFRIVISION |
| Immigration | 5 vidéos, 13 articles, 1 formation | Pages officielles canada.ca, quebec.ca, France-Visas, Campus France, Commission européenne |
| Entrepreneuriat | 3 vidéos, 4 articles, 1 formation | Vidéos de l'ACFC (reproduction non commerciale autorisée par les Avis de Canada.ca), OIT, eRegulations Yaoundé, CNUCED |
| Technologie | 1 vidéo, 4 articles, 1 formation | Vidéo de l'ACFC, Pensez cybersécurité, Elements of AI, fiches AFRIVISION |

**Important :** les vidéos de l'ACFC et d'IRCC sont autorisées pour un usage **non commercial**. Si AFRIVISION devient payant ou affiche de la publicité, il faudra demander une autorisation écrite ou retirer ces vidéos.

## 4. Règles AFRIVISION intégrées au site

- **Immigration** : un contenu de cette rubrique **ne s'affiche pas** sans **source officielle** et sans **date de vérification**. Une fiche ou une vidéo incomplète reste donc invisible au public.
- **Droits d'auteur** : publiez uniquement des vidéos autorisées : chaînes officielles qui permettent l'intégration, licences Creative Commons, domaine public ou accord écrit du créateur. Gardez une trace des autorisations.
- **Pas de faux liens** : chaque source doit être une vraie page, vérifiée.
- **Vérifiez à nouveau** les fiches Immigration régulièrement (par exemple tous les 3 mois) et mettez à jour leur date de vérification.

## 5. Coût et limites de l'offre gratuite Netlify

L'offre gratuite donne **300 crédits par mois**. Au moment de la vérification (19 novembre 2026) :

- chaque **mise à jour publiée** coûte **15 crédits**, soit environ 20 publications par mois si rien d'autre ne consomme ;
- la **bande passante** coûte 20 crédits par Go ;
- les **formulaires** (page Contact) sont gratuits.

Si les crédits sont épuisés, le site est mis en pause jusqu'au mois suivant. **Conseils :**

- regroupez vos ajouts : préparez plusieurs vidéos, puis enregistrez-les ensemble ;
- les vidéos sont hébergées sur YouTube ou Vimeo, pas sur Netlify : elles ne consomment presque pas de crédits ;
- compressez les images avant de les envoyer (moins de 200 Ko).

Source : documentation Netlify, « How credits work ».

## 6. Entretien technique

- **Aperçu de partage** : l'image `assets/img/partage.png` s'affiche quand on partage un lien du site (WhatsApp, Facebook…).
- **Plan du site** : `sitemap.xml` est recréé automatiquement à chaque publication. Vous pouvez le déclarer dans Google Search Console.
- **Espace de gestion** : la version de Sveltia CMS est fixée (0.269.2) et vérifiée par empreinte dans `admin/index.html`. Pour la mettre à jour, il faut changer le numéro de version **et** l'empreinte `integrity` : demandez de l'aide pour le faire.

## 7. Après la mise en ligne

1. Dans Netlify, allez dans **Forms**, activez la détection des formulaires (« Enable form detection »), republiez le site, puis activez les notifications par e-mail pour recevoir les messages du formulaire de contact.
2. Testez le formulaire de contact une fois.
3. Facultatif : ajoutez l'e-mail public dans **Réglages du site**.
