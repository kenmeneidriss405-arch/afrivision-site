/* AFRIVISION — script principal
   Le site lit ses contenus dans le dossier /content (fichiers JSON modifiables
   depuis l'espace de gestion /admin). Aucune base de données ni serveur requis. */
(function () {
  'use strict';

  // ---------- Outils ----------
  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  function h(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return ESC[c]; }); }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function param(name) { return new URLSearchParams(location.search).get(name) || ''; }
  function safeUrl(u) {
    u = String(u || '').trim();
    if (/^https?:\/\//i.test(u)) return u;
    if (/^\/(?!\/)[\w\-./%]+$/.test(u)) return u; // fichier du site (ex. /images/uploads/x.jpg)
    return '';
  }
  function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  function fmtDate(iso) {
    if (!/^\d{4}-\d{2}-\d{2}/.test(iso || '')) return '';
    var d = new Date(iso.slice(0, 10) + 'T12:00:00Z');
    try { return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }); }
    catch (e) { return iso.slice(0, 10); }
  }
  function hash(s) { var x = 0; s = String(s); for (var i = 0; i < s.length; i++) { x = (x * 31 + s.charCodeAt(i)) | 0; } return Math.abs(x); }

  // ---------- Icônes (SVG en ligne) ----------
  var I = {
    search: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>',
    menu: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
    close: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    home: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M4 11l8-7 8 7v9h-5v-6h-6v6H4z"/></svg>',
    grid: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/></svg>',
    bookmark: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M6 4h12v16l-6-4-6 4z"/></svg>',
    play: '<svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4.5v15l13-7.5z" fill="currentColor"/></svg>',
    playBig: '<svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>',
    info: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/></svg>',
    shield: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg>',
    ext: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true" style="margin-top:4px;flex-shrink:0"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
    mail: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>',
    t_video: '<svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>',
    t_formation: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round" aria-hidden="true"><path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c3 2 9 2 12 0v-5"/></svg>',
    t_article: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 4h9l3 3v13H6z"/><path d="M9 11h6M9 15h6"/></svg>'
  };
  var RUB_ICON = {
    media: '<path d="M4 6h16v12H4z"/><path d="M10 9.5v5l4-2.5z" fill="currentColor"/>',
    academy: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c3 2 9 2 12 0v-5"/>',
    'developpement-personnel': '<path d="M12 3v3M5.6 5.6l2.1 2.1M3 12h3M18 12h3M16.3 7.7l2.1-2.1"/><circle cx="12" cy="14" r="4"/><path d="M8 21h8"/>',
    immigration: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/>',
    entrepreneuriat: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    technologie: '<rect x="4" y="5" width="16" height="11" rx="1.5"/><path d="M8 20h8M12 16v4"/>'
  };
  function rubIcon(id) {
    return '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (RUB_ICON[id] || RUB_ICON.media) + '</svg>';
  }
  var TYPE_LABEL = { video: 'Vidéo', formation: 'Formation', article: 'Article' };

  // ---------- Affiches générées (quand il n'y a pas d'image) ----------
  var PALETTES = [['#0F4C4A', '#08201F'], ['#1F2E66', '#0C122B'], ['#5A2A6B', '#1F0E26'], ['#6E4A10', '#241805'], ['#7A2E14', '#2A0F07'], ['#3B4A1A', '#141A08'], ['#1E3F66', '#0A1626']];
  function posterArt(seed, wide) {
    var p = PALETTES[hash(seed) % PALETTES.length], gid = 'g' + hash(seed + (wide ? 'w' : ''));
    var vb = wide ? '0 0 320 180' : '0 0 200 300';
    var sun = wide ? '<circle cx="235" cy="62" r="34" fill="#D4A63A" opacity=".85"/>' : '<circle cx="140" cy="92" r="34" fill="#D4A63A" opacity=".85"/>';
    var y = wide ? 118 : 160, w = wide ? 320 : 200, z1 = '', z2 = '';
    for (var x = 0; x <= w; x += 25) { z1 += (x === 0 ? 'M' : 'L') + x + ' ' + (y - ((x / 25) % 2 ? 24 : 0)); z2 += (x === 0 ? 'M' : 'L') + x + ' ' + (y + 14 - ((x / 25) % 2 ? 24 : 0)); }
    return '<svg class="' + (wide ? 'hero-art' : 'poster-art') + '" viewBox="' + vb + '" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="' + gid + '" x1="0" y1="0" x2=".6" y2="1"><stop offset="0" stop-color="' + p[0] + '"/><stop offset="1" stop-color="' + p[1] + '"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#' + gid + ')"/>' + sun +
      '<path d="' + z1 + '" fill="none" stroke="#F2711C" stroke-width="2.5" opacity=".8"/><path d="' + z2 + '" fill="none" stroke="#F5F5F5" stroke-width="1.2" opacity=".35"/></svg>';
  }

  // ---------- Vidéo : reconnaissance des liens ----------
  function parseVideo(url) {
    url = safeUrl(url); if (!url) return null;
    var m;
    if ((m = url.match(/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|live\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/))) {
      return { provider: 'YouTube', embed: 'https://www.youtube-nocookie.com/embed/' + m[1] + '?autoplay=1&rel=0&modestbranding=1', thumb: 'https://i.ytimg.com/vi/' + m[1] + '/hqdefault.jpg' };
    }
    if ((m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/))) return { provider: 'Vimeo', embed: 'https://player.vimeo.com/video/' + m[1] + '?autoplay=1', thumb: '' };
    if ((m = url.match(/^https:\/\/video\.blender\.org\/(?:w|videos\/watch|videos\/embed)\/([A-Za-z0-9-]{8,40})/))) return { provider: 'Blender Video (PeerTube)', embed: 'https://video.blender.org/videos/embed/' + m[1] + '?autoplay=1&title=0&warningTitle=0', thumb: '' };
    if ((m = url.match(/archive\.org\/(?:details|embed)\/([A-Za-z0-9_.\-]+)/))) return { provider: 'Internet Archive', embed: 'https://archive.org/embed/' + m[1], thumb: 'https://archive.org/services/img/' + m[1] };
    if (/\.(mp4|webm)(\?.*)?$/i.test(url)) return { provider: 'Fichier vidéo', file: url, thumb: '' };
    return null;
  }

  // ---------- Chargement et contrôle des contenus ----------
  var DB = null;
  function getJSON(path) {
    return fetch(path, { cache: 'no-cache' }).then(function (r) { if (!r.ok) throw new Error(path + ' ' + r.status); return r.json(); });
  }
  function load() {
    if (DB) return Promise.resolve(DB);
    return Promise.all(['site', 'rubriques', 'videos', 'formations', 'articles'].map(function (n) {
      return getJSON('content/' + n + '.json').catch(function (e) { console.error('AFRIVISION : impossible de lire', e); return n === 'site' ? {} : { items: [] }; });
    })).then(function (r) {
      var site = r[0] || {}, rubs = (r[1].items || []).filter(function (x) { return x && x.id && x.nom; });
      var rubMap = {}; rubs.forEach(function (x) { rubMap[x.id] = x; });
      var all = [];
      function add(list, type) {
        (list || []).forEach(function (it) {
          if (!it || !it.id || !it.titre || !/^[a-z0-9-]+$/.test(it.id)) { console.warn('AFRIVISION : contenu ignoré (id ou titre manquant/invalide)', it); return; }
          it.type = type; it.rub = rubMap[it.rubrique] || null;
          it.href = type + '.html?id=' + encodeURIComponent(it.id);
          it.desc = it.description || it.resume || '';
          if (type === 'video') { it.v = parseVideo(it.video_url); if (!it.v) { console.warn('AFRIVISION : lien vidéo non reconnu', it.id); return; } }
          // Règle AFRIVISION : une information migratoire doit citer ses sources et sa date de vérification.
          if (it.rub && it.rub.verification_obligatoire) {
            var hasSrc = type === 'article' ? (it.sources || []).some(function (s) { return safeUrl(s && s.url); }) : type === 'video' ? !!safeUrl(it.source_url) : true;
            if (!it.date_verification || !hasSrc) { console.warn('AFRIVISION : contenu masqué — sources officielles ou date de vérification manquantes', it.id); return; }
          }
          all.push(it);
        });
      }
      add(r[2].items, 'video'); add(r[3].items, 'formation'); add(r[4].items, 'article');
      var byKey = {}; all.forEach(function (it) { byKey[it.type + ':' + it.id] = it; });
      all.forEach(function (it) {
        it.thumb = safeUrl(it.image) || (it.v && it.v.thumb) || '';
        if (it.type === 'formation') {
          it.mods = (it.modules || []).map(function (m) { return { titre: m.titre, description: m.description, target: byKey[(m.type || 'video') + ':' + m.ref] || null }; }).filter(function (m) { return m.target && m.titre; });
          if (!it.thumb) { var fv = it.mods.filter(function (m) { return m.target.thumb; })[0]; if (fv) it.thumb = fv.target.thumb; }
        }
      });
      all.sort(function (a, b) { return String(b.date_publication || '').localeCompare(String(a.date_publication || '')); });
      DB = { site: site, rubs: rubs, rubMap: rubMap, all: all, byKey: byKey };
      return DB;
    });
  }

  // ---------- Mini-Markdown sécurisé ----------
  function inline(t) {
    return h(t)
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/(^|[^*])\*([^*\s][^*]*)\*/g, '$1<em>$2</em>')
      .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  }
  function md(src) {
    var out = [], lines = String(src || '').replace(/\r/g, '').split('\n'), list = null, para = [];
    function flushP() { if (para.length) { out.push('<p>' + inline(para.join(' ')) + '</p>'); para = []; } }
    function flushL() { if (list) { out.push('</' + list + '>'); list = null; } }
    lines.forEach(function (ln) {
      var m;
      if (!ln.trim()) { flushP(); flushL(); return; }
      if ((m = ln.match(/^(#{2,3})\s+(.*)$/))) { flushP(); flushL(); out.push('<h' + m[1].length + '>' + inline(m[2]) + '</h' + m[1].length + '>'); return; }
      if ((m = ln.match(/^\s*[-*]\s+(.*)$/))) { flushP(); if (list !== 'ul') { flushL(); out.push('<ul>'); list = 'ul'; } out.push('<li>' + inline(m[1]) + '</li>'); return; }
      if ((m = ln.match(/^\s*\d+[.)]\s+(.*)$/))) { flushP(); if (list !== 'ol') { flushL(); out.push('<ol>'); list = 'ol'; } out.push('<li>' + inline(m[1]) + '</li>'); return; }
      flushL(); para.push(ln.trim());
    });
    flushP(); flushL();
    return out.join('');
  }

  // ---------- Ma liste (favoris dans le navigateur) ----------
  var FAV_KEY = 'afrivision:liste';
  function favs() { try { return JSON.parse(localStorage.getItem(FAV_KEY) || '[]'); } catch (e) { return []; } }
  function setFavs(a) { try { localStorage.setItem(FAV_KEY, JSON.stringify(a)); return true; } catch (e) { return false; } }
  function favButton(it) {
    var key = it.type + ':' + it.id, on = favs().indexOf(key) > -1;
    return '<button type="button" class="btn btn-ghost fav-btn" data-fav="' + h(key) + '" aria-pressed="' + on + '">' + I.bookmark.replace('width="22" height="22"', 'width="18" height="18"') + '<span>' + (on ? 'Dans ma liste' : 'Ajouter à ma liste') + '</span></button>';
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-fav]'); if (!b) return;
    var key = b.getAttribute('data-fav'), a = favs(), i = a.indexOf(key);
    if (i > -1) a.splice(i, 1); else a.unshift(key);
    if (!setFavs(a)) { alert('Votre navigateur ne permet pas d’enregistrer la liste (navigation privée ?).'); return; }
    var on = i === -1; b.setAttribute('aria-pressed', on); b.querySelector('span').textContent = on ? 'Dans ma liste' : 'Ajouter à ma liste';
  });

  // ---------- Composants ----------
  function card(it, opts) {
    opts = opts || {};
    var tag = it.rub ? (it.rub.court || it.rub.nom) : '';
    var img = it.thumb ? '<img src="' + h(it.thumb) + '" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer">' : posterArt(it.id, false);
    return '<a class="card" href="' + h(it.href) + '"><div class="poster">' + img +
      (tag && !opts.noTag ? '<span class="poster-tag">' + h(tag) + '</span>' : '') +
      '<span class="poster-type" aria-hidden="true">' + I['t_' + it.type] + '</span><div class="poster-shade"></div>' +
      '<span class="poster-title"><span class="visually-hidden">' + TYPE_LABEL[it.type] + ' : </span>' + h(it.titre) + '</span></div>' +
      '<span class="card-desc">' + h(it.desc) + '</span></a>';
  }
  function countFor(db, r) { return db.all.filter(function (x) { return x.rubrique === r.id; }).length; }
  function rubCard(db, x) {
    var n = countFor(db, x);
    return '<a class="card" href="rubrique.html?r=' + h(x.id) + '"><div class="poster">' + posterArt(x.id, false) + '<span class="rub-icon" aria-hidden="true">' + rubIcon(x.id) + '</span><div class="poster-shade"></div><span class="poster-title">' + h(x.nom) + '</span></div><span class="card-desc">' + n + (n > 1 ? ' contenus' : ' contenu') + ' · ' + h(x.description) + '</span></a>';
  }
  function emptyBox(msg) { return '<div class="empty">' + msg + '</div>'; }
  function row(title, items, moreHref, emptyMsg, moreLabel) {
    return '<section class="section"><div class="section-head"><h2>' + h(title) + '</h2>' + (moreHref ? '<a href="' + h(moreHref) + '">' + h(moreLabel || 'Voir tout') + '</a>' : '') + '</div>' +
      (items.length ? '<div class="row">' + items.map(function (it) { return card(it); }).join('') + '</div>' : emptyBox(emptyMsg || 'Les premiers contenus de cette rubrique arrivent bientôt.')) + '</section>';
  }
  function notice(dateIso) {
    return '<div class="notice" role="note">' + I.shield + '<div><strong>Information vérifiée' + (dateIso ? ' le ' + h(fmtDate(dateIso)) : '') + ' sur des sites officiels.</strong> Les règles d’immigration changent souvent : confirmez toujours sur les sources officielles avant toute démarche. AFRIVISION n’est ni un service gouvernemental ni un consultant en immigration.</div></div>';
  }
  function noticeCompact() {
    return '<details class="notice notice-compact"><summary>' + I.shield + '<span><strong>Sources officielles et date de vérification sur chaque fiche.</strong> <span class="more">En savoir plus</span></span></summary><p>Les règles d’immigration changent souvent : confirmez toujours sur les sources officielles avant toute démarche. AFRIVISION n’est ni un service gouvernemental ni un consultant en immigration.</p></details>';
  }
  function playerHTML(v, poster, title, size) {
    if (!v) return '';
    if (v.file) return '<div class="player"><video controls preload="none" playsinline' + (poster ? ' poster="' + h(poster) + '"' : '') + '><source src="' + h(v.file) + '"></video></div>' +
      '<p class="player-note">Fichier vidéo hébergé par la source officielle' + (size ? ' · <strong>' + h(size) + '</strong> : de préférence en Wi-Fi' : '') + '. Le téléchargement commence seulement quand vous appuyez sur lecture.</p>';
    return '<div class="player" data-embed="' + h(v.embed) + '" data-title="' + h(title) + '"><button type="button" class="player-cover" aria-label="Lire la vidéo : ' + h(title) + '">' +
      (poster ? '<img src="' + h(poster) + '" alt="" referrerpolicy="no-referrer">' : posterArt(title, true)) + '<span class="play">' + I.playBig + '</span></button></div>' +
      '<p class="player-note">Lecteur fourni par ' + h(v.provider) + '. Il se charge uniquement quand vous appuyez sur lecture.</p>';
  }
  document.addEventListener('click', function (e) {
    var c = e.target.closest && e.target.closest('.player-cover'); if (!c) return;
    var box = c.parentNode, f = document.createElement('iframe');
    f.src = box.getAttribute('data-embed'); f.title = box.getAttribute('data-title') || 'Lecteur vidéo';
    f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen'; f.allowFullscreen = true; f.referrerPolicy = 'strict-origin-when-cross-origin';
    box.innerHTML = ''; box.appendChild(f);
  });
  function sourcesList(list) {
    var ok = (list || []).filter(function (s) { return s && safeUrl(s.url); });
    if (!ok.length) return '';
    return '<ul class="sources">' + ok.map(function (s) { return '<li><a href="' + h(safeUrl(s.url)) + '" target="_blank" rel="noopener noreferrer">' + I.ext + '<span>' + h(s.titre || s.url) + '</span></a></li>'; }).join('') + '</ul>';
  }
  function setMeta(title, desc) {
    document.title = title ? title + ' — AFRIVISION' : 'AFRIVISION';
    var m = $('meta[name="description"]'); if (m && desc) m.setAttribute('content', desc.slice(0, 160));
  }
  function crumbs(parts) {
    return '<nav class="breadcrumb" aria-label="Fil d’Ariane"><a href="index.html">Accueil</a>' + parts.map(function (p) { return ' › ' + (p[1] ? '<a href="' + h(p[1]) + '">' + h(p[0]) + '</a>' : '<span>' + h(p[0]) + '</span>'); }).join('') + '</nav>';
  }
  function notFound(main, what) {
    setMeta('Introuvable');
    main.innerHTML = '<div class="container"><div class="page-head"><h1>' + h(what) + ' introuvable</h1><p class="lead">Ce contenu n’existe pas ou a été retiré.</p></div><a class="btn btn-primary" href="index.html">Retour à l’accueil</a></div>';
  }

  // ---------- Coquille (en-tête, menu, barre du bas, pied de page) ----------
  function shell(db) {
    var page = document.body.getAttribute('data-page'), cur = param('r');
    var nav = db.rubs.map(function (r) {
      var c = (page === 'rubrique' && cur === r.id) ? ' aria-current="page"' : '';
      return '<a href="rubrique.html?r=' + h(r.id) + '"' + c + '>' + h(r.court || r.nom) + '</a>';
    }).join('');
    var hd = $('#app-header');
    if (hd) hd.outerHTML = '<header class="site-header" id="site-header"><div class="container header-inner">' +
      '<a class="logo" href="index.html" aria-label="AFRIVISION, accueil"><img src="assets/img/logo-mark.svg" width="28" height="28" alt=""><span class="logo-text">AFRI<span>VISION</span></span></a>' +
      '<nav class="main-nav" aria-label="Rubriques">' + nav + '</nav>' +
      '<div class="header-actions"><a class="icon-btn" href="recherche.html" aria-label="Rechercher">' + I.search + '</a><button type="button" class="icon-btn menu-btn" aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="drawer">' + I.menu + '</button></div></div></header>' +
      '<div class="drawer-backdrop" data-close-drawer></div><aside class="drawer" id="drawer" aria-label="Menu" hidden><div class="drawer-head"><span class="logo-text">AFRI<span>VISION</span></span><button type="button" class="icon-btn" data-close-drawer aria-label="Fermer le menu">' + I.close + '</button></div><nav>' +
      '<a href="index.html">' + I.home + 'Accueil</a><a href="rubrique.html">' + I.grid + 'Toutes les rubriques</a>' + db.rubs.map(function (r) { return '<a href="rubrique.html?r=' + h(r.id) + '">' + rubIcon(r.id) + h(r.nom) + '</a>'; }).join('') +
      '<div class="drawer-sep"></div><a href="liste.html">' + I.bookmark + 'Ma liste</a><a href="a-propos.html">' + I.info.replace(/18/g, '22') + 'À propos</a><a href="contact.html">' + I.mail + 'Contact</a></nav></aside>';
    var tb = $('#app-tabbar');
    if (tb) {
      var t = function (href, icon, label, key) { return '<a href="' + href + '"' + (page === key ? ' aria-current="page"' : '') + '>' + icon + label + '</a>'; };
      tb.outerHTML = '<nav class="tabbar" aria-label="Navigation principale">' + t('index.html', I.home, 'Accueil', 'home') + t('recherche.html', I.search, 'Recherche', 'recherche') +
        '<button type="button" class="menu-btn"' + (page === 'rubrique' ? ' aria-current="page"' : '') + ' aria-controls="drawer" aria-expanded="false">' + I.grid + 'Rubriques</button>' + t('liste.html', I.bookmark, 'Ma liste', 'liste') + '</nav>';
    }
    var ft = $('#app-footer');
    if (ft) ft.outerHTML = '<footer class="site-footer"><div class="container"><div class="footer-grid">' +
      '<div class="footer-about"><span class="logo-text">AFRI<span>VISION</span></span><p>' + h(db.site.slogan || '') + '</p><p>Tous les contenus sont diffusés avec l’autorisation de leurs ayants droit ou depuis des sources officielles qui permettent leur intégration.</p></div>' +
      '<div><h2>Rubriques</h2><ul><li><a href="rubrique.html">Toutes les rubriques</a></li>' + db.rubs.map(function (r) { return '<li><a href="rubrique.html?r=' + h(r.id) + '">' + h(r.nom) + '</a></li>'; }).join('') + '</ul></div>' +
      '<div><h2>AFRIVISION</h2><ul><li><a href="a-propos.html">À propos</a></li><li><a href="contact.html">Contact</a></li><li><a href="contact.html?sujet=signaler">Signaler un contenu</a></li><li><a href="mentions-legales.html">Mentions légales et droits</a></li></ul></div>' +
      '</div><div class="footer-bottom"><span>© ' + new Date().getFullYear() + ' AFRIVISION. Plateforme gratuite.</span><span>Informer · Éduquer · Divertir</span></div></div></footer>';

    // Menu mobile
    var drawer = $('#drawer'), lastFocus = null;
    function openD() { if (!drawer) return; lastFocus = document.activeElement; drawer.hidden = false; requestAnimationFrame(function () { document.body.classList.add('drawer-open'); }); document.querySelectorAll('.menu-btn').forEach(function (b) { b.setAttribute('aria-expanded', 'true'); }); var f = drawer.querySelector('a,button'); if (f) f.focus(); }
    function closeD() { if (!drawer || !document.body.classList.contains('drawer-open')) return; document.body.classList.remove('drawer-open'); document.querySelectorAll('.menu-btn').forEach(function (b) { b.setAttribute('aria-expanded', 'false'); }); setTimeout(function () { drawer.hidden = true; }, 260); if (lastFocus) lastFocus.focus(); }
    document.addEventListener('click', function (e) {
      if (e.target.closest('.menu-btn')) { openD(); return; }
      if (e.target.closest('[data-close-drawer]')) closeD();
    });
    document.addEventListener('keydown', function (e) {
      if (!document.body.classList.contains('drawer-open')) return;
      if (e.key === 'Escape') { closeD(); return; }
      if (e.key === 'Tab') { // garder la sélection dans le menu ouvert
        var f = drawer.querySelectorAll('a[href],button'); if (!f.length) return;
        var first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        else if (!drawer.contains(document.activeElement)) { e.preventDefault(); first.focus(); }
      }
    });
    var head = $('#site-header');
    window.addEventListener('scroll', function () { if (head) head.classList.toggle('scrolled', window.scrollY > 8); }, { passive: true });
  }

  // ---------- Pages ----------
  var PAGES = {};

  PAGES.home = function (main, db) {
    setMeta('', db.site.mission);
    var feat = db.all.filter(function (x) { return x.a_la_une; })[0] || db.all[0];
    var hero = '';
    if (feat) {
      var action = feat.type === 'video' ? 'Regarder' : feat.type === 'formation' ? 'Commencer' : 'Lire';
      hero = '<section class="hero" aria-label="À la une">' + (feat.thumb ? '<img class="hero-img" src="' + h(feat.thumb) + '" alt="" referrerpolicy="no-referrer">' : posterArt(feat.id, true)) +
        '<div class="hero-body"><span class="badge">À la une</span><h1>' + h(feat.titre) + '</h1><p class="hero-meta">' + h(TYPE_LABEL[feat.type]) + (feat.rub ? ' · ' + h(feat.rub.nom) : '') + (feat.mods ? ' · ' + feat.mods.length + ' modules' : '') + '</p>' +
        '<p class="hero-desc">' + h(feat.desc) + '</p><div class="btn-row"><a class="btn btn-primary" href="' + h(feat.href) + '">' + I.play + action + '</a>' +
        (feat.rub ? '<a class="btn btn-ghost" href="rubrique.html?r=' + h(feat.rub.id) + '">' + I.info + 'Voir plus</a>' : '') + '</div></div></section>';
    }
    var chips = '<nav class="chips" aria-label="Filtrer par rubrique"><button type="button" class="chip" data-filter="" aria-pressed="true">Tout</button>' +
      db.rubs.map(function (r) { return '<button type="button" class="chip" data-filter="' + h(r.id) + '" aria-pressed="false">' + h(r.court || r.nom) + '</button>'; }).join('') + '</nav>';
    var recents = '<div data-group="">' + row('Contenus récents', db.all.slice(0, 12), 'recherche.html', 'Aucun contenu pour le moment.', 'Tous les contenus') + '</div>';
    var rows = db.rubs.map(function (r) {
      var items = db.all.filter(function (x) { return x.rubrique === r.id; }).slice(0, 15);
      return '<div data-group="' + h(r.id) + '">' + row(r.nom, items, 'rubrique.html?r=' + r.id, '<strong>Bientôt sur AFRIVISION.</strong> ' + h(r.description)) + '</div>';
    }).join('');
    main.innerHTML = '<div class="container">' + chips + hero + recents + rows + '</div>';
    main.addEventListener('click', function (e) {
      var c = e.target.closest('[data-filter]'); if (!c) return;
      var f = c.getAttribute('data-filter');
      main.querySelectorAll('[data-filter]').forEach(function (b) { b.setAttribute('aria-pressed', String(b === c)); });
      main.querySelectorAll('[data-group]').forEach(function (g) { var k = g.getAttribute('data-group'); g.hidden = f ? k !== f : false; });
      var hr = main.querySelector('.hero'); if (hr) hr.hidden = !!f;
    });
  };

  PAGES.rubrique = function (main, db) {
    var r = db.rubMap[param('r')];
    if (!r) {
      setMeta('Rubriques', 'Toutes les rubriques d’AFRIVISION');
      main.innerHTML = '<div class="container"><div class="page-head"><p class="eyebrow">Explorer</p><h1>Toutes les rubriques</h1></div><div class="grid">' +
        db.rubs.map(function (x) { return rubCard(db, x); }).join('') + '</div></div>';
      return;
    }
    setMeta(r.nom, r.description);
    var items = db.all.filter(function (x) { return x.rubrique === r.id; });
    var subs = (r.sous_categories || []).map(function (s) { return { nom: s, n: items.filter(function (x) { return x.sous_categorie === s; }).length }; }).filter(function (s) { return s.n > 0; });
    var others = items.filter(function (x) { return (r.sous_categories || []).indexOf(x.sous_categorie) === -1; });
    var stats = { video: 0, formation: 0, article: 0 }; items.forEach(function (x) { stats[x.type]++; });
    var statTxt = [['video', 'vidéo'], ['formation', 'formation'], ['article', 'article']].filter(function (t) { return stats[t[0]]; }).map(function (t) { return stats[t[0]] + ' ' + t[1] + (stats[t[0]] > 1 ? 's' : ''); }).join(' · ');
    var chips = subs.length > 1 ? '<nav class="chips" aria-label="Filtrer par thème"><button type="button" class="chip" data-sub="" aria-pressed="true">Tout <span class="chip-n">' + items.length + '</span></button>' + subs.map(function (s) { return '<button type="button" class="chip" data-sub="' + h(s.nom) + '" aria-pressed="false">' + h(s.nom) + ' <span class="chip-n">' + s.n + '</span></button>'; }).join('') + '</nav>' : '';
    main.innerHTML = '<div class="container">' + crumbs([[r.nom]]) + '<div class="page-head rub-head"><span class="rub-badge" aria-hidden="true">' + rubIcon(r.id) + '</span><div><p class="eyebrow">Rubrique' + (statTxt ? ' · ' + statTxt : '') + '</p><h1>' + h(r.nom) + '</h1><p class="lead">' + h(r.description) + '</p></div></div>' +
      (r.verification_obligatoire ? noticeCompact() : '') + chips + '<p class="result-count" id="count" aria-live="polite"></p><div id="list"></div></div>';
    function grid(list) { return '<div class="grid">' + list.map(function (x) { return card(x, { noTag: true }); }).join('') + '</div>'; }
    function draw(sub) {
      var list = sub ? items.filter(function (x) { return x.sous_categorie === sub; }) : items, html;
      $('#count').textContent = list.length ? list.length + (list.length > 1 ? ' contenus' : ' contenu') : 'Aucun contenu';
      if (!list.length) html = emptyBox('<strong>Pas encore de contenu ici.</strong> Les premiers contenus de cette rubrique arrivent bientôt. Vous avez une vidéo autorisée à proposer ? <a href="contact.html?sujet=proposer">Écrivez-nous</a>.');
      else if (sub || subs.length < 2) html = grid(list);
      else html = subs.map(function (s) { return '<section class="section theme"><div class="section-head"><h2>' + h(s.nom) + '</h2>' + (s.n > 1 ? '<button type="button" class="link-btn" data-sub-go="' + h(s.nom) + '">Voir les ' + s.n + '</button>' : '') + '</div>' + grid(items.filter(function (x) { return x.sous_categorie === s.nom; })) + '</section>'; }).join('') +
        (others.length ? '<section class="section theme"><div class="section-head"><h2>Autres contenus</h2></div>' + grid(others) + '</section>' : '');
      $('#list').innerHTML = html;
    }
    draw('');
    main.addEventListener('click', function (e) {
      var go = e.target.closest('[data-sub-go]'), c = e.target.closest('[data-sub]');
      if (go) c = main.querySelector('[data-sub="' + go.getAttribute('data-sub-go').replace(/"/g, '\\"') + '"]');
      if (!c) return;
      main.querySelectorAll('[data-sub]').forEach(function (b) { b.setAttribute('aria-pressed', String(b === c)); });
      draw(c.getAttribute('data-sub'));
      if (go) { var nav = main.querySelector('.chips'); if (nav) nav.scrollIntoView({ block: 'start' }); }
    });
  };

  function suggestions(db, it) {
    var s = db.all.filter(function (x) { return x !== it && x.rubrique === it.rubrique; }).slice(0, 10);
    return s.length ? row('Dans la même rubrique', s, it.rub ? 'rubrique.html?r=' + it.rub.id : '') : '';
  }
  function infoBox(it, extra) {
    var rows = [];
    if (it.rub) rows.push(['Rubrique', '<a href="rubrique.html?r=' + h(it.rub.id) + '">' + h(it.rub.nom) + '</a>' + (it.sous_categorie ? ' · ' + h(it.sous_categorie) : '')]);
    (extra || []).forEach(function (r) { if (r[1]) rows.push(r); });
    if (it.date_verification) rows.push(['Vérifié le', h(fmtDate(it.date_verification))]);
    if (it.date_publication) rows.push(['Ajouté le', h(fmtDate(it.date_publication))]);
    return '<aside class="info-box"><h2>Informations</h2><dl>' + rows.map(function (r) { return '<div><dt>' + r[0] + '</dt><dd>' + r[1] + '</dd></div>'; }).join('') + '</dl></aside>';
  }

  PAGES.video = function (main, db) {
    var it = db.byKey['video:' + param('id')]; if (!it) return notFound(main, 'Vidéo');
    setMeta(it.titre, it.desc);
    var src = safeUrl(it.source_url);
    main.innerHTML = '<div class="container">' + crumbs([[it.rub ? it.rub.nom : 'Vidéos', it.rub ? 'rubrique.html?r=' + it.rub.id : ''], [it.titre]]) +
      '<div class="detail"><div>' + playerHTML(it.v, it.thumb, it.titre, it.taille_fichier) + '<h1>' + h(it.titre) + '</h1><p class="meta-line">Vidéo' + (it.duree ? ' · ' + h(it.duree) : '') + (it.taille_fichier ? ' · ' + h(it.taille_fichier) : '') + (it.rub ? ' · ' + h(it.rub.nom) : '') + '</p>' +
      (it.rub && it.rub.verification_obligatoire ? notice(it.date_verification) : '') +
      '<div class="prose"><p>' + h(it.desc) + '</p></div><div class="actions">' + favButton(it) + '</div></div>' +
      infoBox(it, [['Source', src ? '<a href="' + h(src) + '" target="_blank" rel="noopener noreferrer">' + h(it.source_nom || 'Page officielle') + '</a>' : h(it.source_nom || '')], ['Droits', h(it.licence || '')]]) +
      '</div>' + suggestions(db, it) + '</div>';
  };

  PAGES.article = function (main, db) {
    var it = db.byKey['article:' + param('id')]; if (!it) return notFound(main, 'Article');
    setMeta(it.titre, it.desc);
    main.innerHTML = '<div class="container">' + crumbs([[it.rub ? it.rub.nom : 'Articles', it.rub ? 'rubrique.html?r=' + it.rub.id : ''], [it.titre]]) +
      '<div class="detail"><article><h1>' + h(it.titre) + '</h1><p class="meta-line">Article' + (it.rub ? ' · ' + h(it.rub.nom) : '') + '</p>' +
      (it.date_verification ? notice(it.date_verification) : '') + '<div class="prose">' + md(it.corps) + '</div>' +
      ((it.sources || []).length ? '<section class="section"><div class="section-head"><h2>Sources officielles</h2></div>' + sourcesList(it.sources) + '</section>' : '') +
      '<div class="actions">' + favButton(it) + '</div></article>' + infoBox(it) + '</div>' + suggestions(db, it) + '</div>';
  };

  PAGES.formation = function (main, db) {
    var it = db.byKey['formation:' + param('id')]; if (!it) return notFound(main, 'Formation');
    setMeta(it.titre, it.desc);
    var n = it.mods.length, m = Math.min(Math.max(parseInt(param('m'), 10) || 1, 1), Math.max(n, 1));
    var cur = it.mods[m - 1], base = 'formation.html?id=' + encodeURIComponent(it.id) + '&m=';
    var lesson = '';
    if (cur) {
      var t = cur.target;
      lesson = t.type === 'video' ? playerHTML(t.v, t.thumb, t.titre, t.taille_fichier) :
        '<div class="info-box"><p class="meta-line" style="margin:0 0 6px">Fiche à lire</p><h2 style="font-size:20px">' + h(t.titre) + '</h2><p style="color:#C9C9D1">' + h(t.desc) + '</p><a class="btn btn-primary" href="' + h(t.href) + '">Lire la fiche</a></div>';
      lesson += '<h2 style="font-size:20px;margin-top:16px">Module ' + m + ' : ' + h(cur.titre) + '</h2>' + (cur.description ? '<p style="color:var(--muted);margin:6px 0 0">' + h(cur.description) + '</p>' : '') +
        '<div class="actions">' + (m > 1 ? '<a class="btn btn-ghost" href="' + base + (m - 1) + '">Module précédent</a>' : '') + (m < n ? '<a class="btn btn-primary" href="' + base + (m + 1) + '">Module suivant</a>' : '<span class="badge" style="align-self:center">Dernier module</span>') + '</div>';
    }
    var mods = '<ol class="modules">' + it.mods.map(function (x, i) {
      return '<li><a class="module" href="' + base + (i + 1) + '"' + (i + 1 === m ? ' aria-current="true"' : '') + '><span class="module-num">' + (i + 1) + '</span><span>' + h(x.titre) + '<small>' + h(TYPE_LABEL[x.target.type]) + (x.description ? ' · ' + h(x.description) : '') + '</small></span></a></li>';
    }).join('') + '</ol>';
    main.innerHTML = '<div class="container">' + crumbs([[it.rub ? it.rub.nom : 'Formations', it.rub ? 'rubrique.html?r=' + it.rub.id : ''], [it.titre]]) +
      '<div class="page-head"><p class="eyebrow">Formation gratuite' + (it.niveau ? ' · ' + h(it.niveau) : '') + ' · ' + n + ' modules</p><h1>' + h(it.titre) + '</h1><p class="lead">' + h(it.desc) + '</p></div>' +
      (it.rub && it.rub.verification_obligatoire ? notice(it.date_verification) : '') +
      '<div class="detail"><div>' + (lesson || emptyBox('Les modules de cette formation arrivent bientôt.')) + '</div><div><h2 style="font-size:17px;margin-bottom:10px">Programme</h2>' + mods + '<div class="actions">' + favButton(it) + '</div></div></div>' +
      suggestions(db, it) + '</div>';
  };

  PAGES.recherche = function (main, db) {
    setMeta('Recherche', 'Rechercher une vidéo, une formation ou un article sur AFRIVISION');
    var q0 = param('q');
    main.innerHTML = '<div class="container"><div class="page-head"><h1>Rechercher</h1></div>' +
      '<form class="search-box" role="search" action="recherche.html" id="sform"><label for="q" class="visually-hidden">Rechercher</label><input type="search" id="q" name="q" placeholder="Titre, thème, mot-clé…" value="' + h(q0) + '" autocomplete="off" enterkeyhint="search"><button class="btn btn-primary" type="submit" aria-label="Lancer la recherche">' + I.search + '</button></form>' +
      '<p class="result-count" id="count" aria-live="polite"></p><div id="results"></div></div>';
    var input = $('#q');
    // Mots ignorés et racines : « immigrer » trouve aussi « immigration », « études » trouve « étudier ».
    var STOP = { le: 1, la: 1, les: 1, de: 1, des: 1, du: 1, un: 1, une: 1, et: 1, en: 1, au: 1, aux: 1, a: 1, pour: 1, sur: 1, par: 1, d: 1, l: 1, est: 1, ou: 1, mon: 1, ma: 1, mes: 1, comment: 1 };
    function stem(w) { return w.length > 5 ? w.slice(0, Math.max(5, w.length - 3)) : w; }
    function fields(x) {
      if (!x._s) x._s = { t: norm(x.titre), k: norm([x.sous_categorie, x.rub && x.rub.nom, TYPE_LABEL[x.type]].join(' ')), d: norm(x.desc), b: norm(x.corps || '') };
      return x._s;
    }
    function score(x, words) {
      var f = fields(x), total = 0;
      for (var i = 0; i < words.length; i++) {
        var w = words[i], r = stem(w), sc = 0;
        if (f.t.indexOf(w) > -1) sc += 12; else if (f.t.indexOf(r) > -1) sc += 9;
        if (f.k.indexOf(w) > -1) sc += 6; else if (f.k.indexOf(r) > -1) sc += 4;
        if (f.d.indexOf(w) > -1) sc += 4; else if (f.d.indexOf(r) > -1) sc += 3;
        if (f.b.indexOf(w) > -1) sc += 1; else if (f.b.indexOf(r) > -1) sc += 1;
        if (!sc) return 0; // chaque mot doit apparaître quelque part
        total += sc;
      }
      if (words.length > 1 && f.t.indexOf(words.join(' ')) > -1) total += 10; // expression exacte dans le titre
      return total;
    }
    function run(q) {
      var all = norm(q).replace(/[^a-z0-9\s'-]/g, ' ').split(/[\s'-]+/).filter(Boolean);
      var words = all.filter(function (w) { return !STOP[w]; }); if (!words.length) words = all;
      var list = !words.length ? db.all : db.all.map(function (x, i) { return { x: x, s: score(x, words), i: i }; })
        .filter(function (o) { return o.s > 0; }).sort(function (a, b) { return b.s - a.s || a.i - b.i; }).map(function (o) { return o.x; });
      $('#count').textContent = words.length ? (list.length + ' résultat' + (list.length > 1 ? 's' : '') + ' pour « ' + q + ' »') : 'Tous les contenus (' + list.length + ')';
      $('#results').innerHTML = list.length ? '<div class="grid">' + list.map(function (x) { return card(x); }).join('') + '</div>' : emptyBox('Aucun résultat. Essayez un autre mot, ou parcourez les <a href="rubrique.html">rubriques</a>.');
    }
    run(q0);
    var timer; input.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(function () { run(input.value); history.replaceState(null, '', input.value ? '?q=' + encodeURIComponent(input.value) : 'recherche.html'); }, 200); });
    $('#sform').addEventListener('submit', function (e) { e.preventDefault(); run(input.value); input.blur(); });
    if (!q0 && window.matchMedia('(min-width:900px)').matches) input.focus();
  };

  PAGES.liste = function (main, db) {
    setMeta('Ma liste');
    function draw() {
      var list = favs().map(function (k) { return db.byKey[k]; }).filter(Boolean);
      main.innerHTML = '<div class="container"><div class="page-head"><h1>Ma liste</h1><p class="lead">Vos contenus enregistrés sur cet appareil.</p></div>' +
        (list.length ? '<div class="grid">' + list.map(function (x) { return card(x); }).join('') + '</div>' : emptyBox('<strong>Votre liste est vide.</strong> Appuyez sur « Ajouter à ma liste » sur une vidéo, une formation ou un article pour le retrouver ici.')) + '</div>';
    }
    draw();
  };

  PAGES.apropos = function (main, db) {
    setMeta('À propos', db.site.mission);
    main.innerHTML = '<div class="container"><div class="page-head"><p class="eyebrow">À propos</p><h1>' + h(db.site.nom || 'AFRIVISION') + '</h1><p class="lead">' + h(db.site.mission || '') + '</p></div>' +
      '<div class="prose">' + md(db.site.a_propos) + '</div>' +
      '<section class="section"><div class="section-head"><h2>Nos six rubriques</h2></div><div class="grid">' +
      db.rubs.map(function (x) { return rubCard(db, x); }).join('') +
      '</div></section><div class="actions"><a class="btn btn-primary" href="contact.html">Nous contacter</a></div></div>';
  };

  PAGES.contact = function (main, db) {
    var s = param('sujet'), sel = $('#sujet');
    var map = { proposer: 'Proposer un contenu', signaler: 'Signaler un contenu ou un problème de droits' };
    if (sel && map[s]) sel.value = map[s];
    var mail = $('#contact-mail');
    if (mail && db.site.email_contact && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(db.site.email_contact)) mail.innerHTML = 'Vous pouvez aussi écrire à <a href="mailto:' + h(db.site.email_contact) + '">' + h(db.site.email_contact) + '</a>.';
  };

  // Image indisponible (hors ligne, lien cassé) : on affiche une affiche AFRIVISION à la place.
  document.addEventListener('error', function (e) {
    var img = e.target;
    if (!img || img.tagName !== 'IMG' || img.dataset.fallback) return;
    var box = img.closest('.poster, .hero, .player-cover'); if (!box) return;
    img.dataset.fallback = '1';
    var wide = !box.classList.contains('poster');
    var tmp = document.createElement('div'); tmp.innerHTML = posterArt(box.textContent || 'afrivision', wide);
    img.replaceWith(tmp.firstChild);
  }, true);

  // ---------- Démarrage ----------
  load().then(function (db) {
    shell(db);
    var page = document.body.getAttribute('data-page'), main = $('#app');
    if (PAGES[page] && main) {
      try { PAGES[page](main, db); }
      catch (e) { console.error(e); main.innerHTML = '<div class="container"><p class="loading">Une erreur est survenue. Rechargez la page.</p></div>'; }
    }
  });
})();
