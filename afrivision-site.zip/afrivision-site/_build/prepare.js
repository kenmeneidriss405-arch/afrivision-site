// AFRIVISION — préparation automatique lancée par Netlify à chaque publication.
// 1. Remplace __SITE_URL__ par l'adresse réelle du site (fournie par Netlify dans la variable URL).
// 2. Génère sitemap.xml (plan du site pour Google) à partir des contenus.
// Aucune dépendance : seulement Node.js, présent sur Netlify.
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const raw = (process.env.URL || '').trim().replace(/\/+$/, '');
const SITE = /^https:\/\/[a-z0-9.-]+$/i.test(raw) ? raw : '';

const pages = fs.readdirSync(ROOT).filter((f) => f.endsWith('.html'));
for (const f of pages) {
  const file = path.join(ROOT, f);
  let html = fs.readFileSync(file, 'utf8');
  if (SITE) html = html.split('__SITE_URL__').join(SITE);
  else html = html.replace(/<meta[^>]+__SITE_URL__[^>]*>\n?/g, ''); // sans adresse connue : on retire la balise plutôt que de laisser un faux lien
  fs.writeFileSync(file, html);
}

if (SITE) {
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
  const read = (n) => { try { return JSON.parse(fs.readFileSync(path.join(ROOT, 'content', n + '.json'), 'utf8')).items || []; } catch (e) { return []; } };
  const urls = ['index.html', 'rubrique.html', 'recherche.html', 'a-propos.html', 'contact.html', 'mentions-legales.html'];
  read('rubriques').forEach((r) => urls.push('rubrique.html?r=' + encodeURIComponent(r.id)));
  [['videos', 'video'], ['formations', 'formation'], ['articles', 'article']].forEach(([n, t]) =>
    read(n).forEach((x) => { if (/^[a-z0-9-]+$/.test(x.id || '')) urls.push(t + '.html?id=' + x.id); }));
  const xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
    urls.map((u) => '  <url><loc>' + esc(SITE + '/' + u) + '</loc></url>').join('\n') + '\n</urlset>\n';
  fs.writeFileSync(path.join(ROOT, 'sitemap.xml'), xml);
  fs.appendFileSync(path.join(ROOT, 'robots.txt'), '\nSitemap: ' + SITE + '/sitemap.xml\n');
  console.log('AFRIVISION : adresse ' + SITE + ', sitemap de ' + urls.length + ' pages.');
} else {
  console.log('AFRIVISION : adresse du site inconnue, aperçu de partage et sitemap ignorés.');
}
